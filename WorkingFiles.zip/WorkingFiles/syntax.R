# Hello, 
# R string
"Hello, R"

# Addition
10 + 10

# Multiplication
25 * 3

# Number
12345
