# Declaring variables
name <- "Ahmed"
num1 <- 12
num2 <- 20
text1 <- text2 <- text3 <- "Banana"
