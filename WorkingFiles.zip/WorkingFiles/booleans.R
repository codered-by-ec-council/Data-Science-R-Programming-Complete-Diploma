## Logical Values ##
13 < 3
12 == 12
12 == 10
20 > 19

# Using variables to compare values
x <- 20
y <- 10
