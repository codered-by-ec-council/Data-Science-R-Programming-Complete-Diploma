## Basic math operations ##
# Addition
11 + 23.5
# Subtraction
111 - 55
# Multiplication
3 * 11
# Combination
100 - 32 * 2
# The maximum in a set
max(11, 15, 20)
# The minimum in a set
min(11, 15, 20)
# The square root
sqrt(20)
sqrt(100)
sqrt(16)
# The absolute value
abs(-13.5)
# The ceiling value
ceiling(3.3)
# The floor value
floor(3.3)
